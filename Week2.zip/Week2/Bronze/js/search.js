$("#searchTerm").html($("#searchButton").val());

getSearch($("#searchButton").val());